# TrackingAnalysis-StripHitResolution
